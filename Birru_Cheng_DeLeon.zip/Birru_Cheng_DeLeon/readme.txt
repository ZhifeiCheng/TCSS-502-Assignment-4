* The assignment includes the bonus point using Turtle library to draw the shapes graphically on canvas. An additional .mp4 file showing the outcome was attached.

Team Names:
Raj Birru - rbirru
Zhifei Cheng - zc5dp
Kara DeLeon - deleok

Time it took each person to work on assignment
Raj Birru - 9-12h
Zhifei Cheng - 18-20h
Kara DeLeon - 9h

What each person worked on

Raj Birru:
1) Attended Team Zoom Meetings
2) Code :
	First Path of Shape and shape classes
	DrawingProgramIterator
        Shape Factory
3) Testing:
        Drawing Program Iterator Tests,
        Shape Factories Tests


Zhifei Cheng:
1) Attended Team Zoom Meetings
2) Code :
       	Retouch Shape ABC class shape classes. 
	Add validation method of all shape classes to guarantee the radius, length are 		positive, and three input sides of the triangle can make up a triangle. 
	Add angle calculation for drawing graphics properly.
	DrawingProgram Main: Add get_shape, set_shape, print_shape, merge sort, sort_shape 	functions and etc.
	Add draw_graphic function for all shapes using Turtle library to show shapes in 	graphics		
	
3) Testing:
        DrawingProgramMain
        Getter name property

4) Final check/debug and submit


Kara DeLeon:

1) Meeting coordination and attendance
2) Code :
       	Doc Strings
	Coding print statements for DrawingProgramMain
	Code editing to ensure alignment with assignment requirements	
3) Testing:
        Perimeter and Area function of all shapes
